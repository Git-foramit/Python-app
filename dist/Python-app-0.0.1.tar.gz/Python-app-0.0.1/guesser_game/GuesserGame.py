class Guesser:

    def __init__(self,number=0):

        ''' Generic Guesser class to create a 'diviner' of numbers based on simple arithmetic calculations
        Attributes:
            numberinMind represents the result of "guessing" the number a player has in mind
        '''

        self.numberinMind = number